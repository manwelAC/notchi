Notchi 1.4.0 for Windows x64 — 24 November 2026

Run Notchi.exe. No Python installation is required.
Updating: quit the running Notchi instance, extract this archive, and replace
its previous executable. This release does not include an automatic updater.
Existing local account and appearance preferences remain in %LOCALAPPDATA%\Notchi.

WHAT'S NEW
- Cached animation frames and silhouettes reduce repeated drawing during motion.
- Saved dashboard snapshots appear while Jira refreshes in the background.
- Lightweight parallel role searches; full task details load when opened.
- Refresh timeouts, retry backoff, and a View Last Sync Error menu item.
- Twelve colorways, light/dark modes, gradients and adaptive text colors.
  Graphite Dark retains the original default near-black appearance.
- Optional Side docking toggle in Settings. Enable it, then drag the notch
  to the left, right or top edge. Disable it to return to the top.
- Borderless Settings and task panels with traffic-light window controls.
- Refined typography, custom status dropdowns, and interactive button feedback.
- Change task status in the inspector using actions allowed by Jira's workflow.
  Enter required transition fields when prompted, then save to Jira.

No fixed FPS or network-latency guarantee is made. Performance depends on the
machine, network, Jira permissions, workflow, and account data.

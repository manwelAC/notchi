﻿Notchi v1.2.0 — Hardware-Grade Jira Notch for Windows (x64)
============================================================

QUICK START
1. Double-click Notchi.exe to launch the top-bezel notch widget.
2. Hover over the notch at the top-center of your display to expand it.
3. Enter your Jira Cloud URL, Project Key, Atlassian Email, and API Token.
4. Click "Save & Connect" — your account is cached locally in %LOCALAPPDATA%\Notchi\
   so you never need to log in again unless your Atlassian API token expires.

CONTROLS
- Hover top bezel: Smooth 120Hz expand / collapse
- Click any status card: Bubble-open floating task list for that Kanban column
- Click any task row: Bubble-open full task inspector (Key details, Description, Attachments)
- Drag horizontally: Move anywhere across dual or triple monitors
- Double-click notch: Snap to exact center of current monitor
- Right-click notch: Quick actions menu (Refresh, Pin, API Key renewal, Monitor snap, Quit)

﻿========================================================================
  NOTCHI — Top-Bezel Jira Cloud Kanban Notch for Windows 10 & 11 (v1.3.0)
========================================================================

WHAT'S NEW IN v1.3.0:
  - Custom Space Switcher Popover Modal: Click the Board pill (e.g. 'SM360 Board')
    inside the notch to open a custom hardware-rounded dark modal with live
    search filtering across all 24 Jira spaces and task count badges.
  - Automatic Dev & IQA Role Detection: Queries both Developer assignments
    (Assignee) and IQA Officer tasks (IQA Officer field / Watcher) with a
    1-click 'Role: DEV / IQA / ALL' toggle pill.
  - Multi-Space Auto-Discovery: Automatically detects which Kanban spaces
    you have tasks in—no need to manually know your project key.

QUICK START:
  1. Double-click Notchi.exe to launch.
  2. Move your cursor to the top-center bezel of your screen to expand Notchi.
  3. On first launch, click 'Get New API Key', create an Atlassian API Token,
     and paste your Jira Site URL, Email, and API Token (leave Space as AUTO).
  4. Your account session is cached locally in %LOCALAPPDATA%\Notchi\ so you
     stay signed in across restarts until your API token expires.

CONTROLS:
  - Hover top-center notch: Expand live Kanban status dashboard
  - Click Board Pill ('SM360 Board'): Open Space Switcher modal with search
  - Click Role Pill ('Role: DEV/IQA'): Switch between Dev, IQA, or All tasks
  - Click any Kanban Status Card: Open bubble-animated task list
  - Click any Task Row: Open full Task Inspector (FRD Document ID, ADF description, attachments)
  - Drag anywhere on the notch: Move smoothly across dual/triple monitors
  - Double-click top grip bar: Snap notch to the center of the current monitor

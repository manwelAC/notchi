Notchi 1.5.0 - Windows 10/11 x64

UPGRADING FROM 1.4.0 OR EARLIER
Quit Notchi, extract this ZIP, and replace your previous Notchi.exe.
Run Notchi.exe from a writable folder.
Your preferences remain in %LOCALAPPDATA%\Notchi.

FUTURE UPDATES
Open Settings > Check for updates.
When a newer release is available, click Update and restart.
Requires Windows PowerShell. Downloads are checked for size and SHA-256.
